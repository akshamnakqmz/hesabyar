import { getDB } from "./db.js";

const STORES = [
    "sales",
    "customers",
    "payments",
    "expenses"
];

const BACKUP_VERSION = 1;


// دریافت تمام اطلاعات دیتابیس
function readAllData(db) {

    return new Promise((resolve, reject) => {

        const transaction = db.transaction(
            STORES,
            "readonly"
        );

        const data = {};

        for (const storeName of STORES) {

            const request = transaction
                .objectStore(storeName)
                .getAll();

            request.onsuccess = () => {
                data[storeName] = request.result;
            };

            request.onerror = () => {
                reject(
                    request.error ||
                    new Error("خواندن اطلاعات ناموفق بود.")
                );
            };

        }

        transaction.oncomplete = () => {
            resolve(data);
        };

        transaction.onerror = () => {
            reject(
                transaction.error ||
                new Error("خطا هنگام خواندن دیتابیس.")
            );
        };

        transaction.onabort = () => {
            reject(
                transaction.error ||
                new Error("خواندن اطلاعات لغو شد.")
            );
        };

    });

}


// تهیه نسخه پشتیبان
export async function exportBackup() {

    const db = getDB();

    const data = await readAllData(db);

    const backup = {
        app: "HesabYar",
        version: BACKUP_VERSION,
        createdAt: new Date().toISOString(),
        data: data
    };

    const json = JSON.stringify(
        backup,
        null,
        2
    );

    const blob = new Blob(
        [json],
        { type: "application/json" }
    );

    const url = URL.createObjectURL(blob);

    const link = document.createElement("a");

    const date = new Date()
        .toISOString()
        .slice(0, 10);

    link.href = url;

    link.download = `HesabYar-Backup-${date}.json`;

    document.body.appendChild(link);

    link.click();

    link.remove();

    setTimeout(() => {
        URL.revokeObjectURL(url);
    }, 1500);

    return true;

}


// بررسی اعتبار فایل پشتیبان
function validateBackup(backup) {

    if (
        !backup ||
        backup.app !== "HesabYar" ||
        backup.version !== BACKUP_VERSION ||
        !backup.data
    ) {
        throw new Error(
            "فایل پشتیبان معتبر نیست."
        );
    }

    for (const storeName of STORES) {

        const records = backup.data[storeName];

        if (!Array.isArray(records)) {

            throw new Error(
                `اطلاعات بخش ${storeName} معتبر نیست.`
            );

        }

        for (const record of records) {

            if (
                !record ||
                typeof record !== "object" ||
                Array.isArray(record) ||
                !("id" in record) ||
                !["number", "string"].includes(typeof record.id) ||
                (
                    typeof record.id === "number" &&
                    !Number.isFinite(record.id)
                )
            ) {

                throw new Error(
                    `یکی از اطلاعات بخش ${storeName} معتبر نیست.`
                );

            }

        }

    }

    return backup;

}


// جایگزینی اطلاعات دیتابیس با نسخه پشتیبان
function restoreData(db, backup) {

    return new Promise((resolve, reject) => {

        const transaction = db.transaction(
            STORES,
            "readwrite"
        );

        transaction.oncomplete = () => {
            resolve(true);
        };

        transaction.onerror = () => {
            reject(
                transaction.error ||
                new Error("بازیابی اطلاعات ناموفق بود.")
            );
        };

        transaction.onabort = () => {
            reject(
                transaction.error ||
                new Error("بازیابی اطلاعات لغو شد.")
            );
        };

        try {

            for (const storeName of STORES) {

                const store = transaction.objectStore(
                    storeName
                );

                store.clear();

                for (const record of backup.data[storeName]) {

                    store.put(record);

                }

            }

        } catch (error) {

            transaction.abort();

            reject(error);

        }

    });

}


// بازیابی نسخه پشتیبان
export async function importBackup(file) {

    if (!file) {

        throw new Error(
            "فایل پشتیبان انتخاب نشده است."
        );

    }

    const text = await file.text();

    let backup;

    try {

        backup = JSON.parse(text);

    } catch {

        throw new Error(
            "محتوای فایل پشتیبان معتبر نیست."
        );

    }

    validateBackup(backup);

    const db = getDB();

    await restoreData(db, backup);

    return true;

}


// راه‌اندازی دکمه‌های پشتیبان‌گیری
export function initBackupUI() {

    const exportButton = document.getElementById(
        "backup-export"
    );

    const importButton = document.getElementById(
        "backup-import"
    );

    const fileInput = document.getElementById(
        "backup-file"
    );

    const status = document.getElementById(
        "backup-status"
    );

    if (
        !exportButton ||
        !importButton ||
        !fileInput ||
        !status
    ) {

        console.warn(
            "Backup interface was not found."
        );

        return;

    }


    // تهیه نسخه پشتیبان
    exportButton.addEventListener("click", async () => {

        exportButton.disabled = true;

        status.textContent = "در حال تهیه نسخه پشتیبان...";

        try {

            await exportBackup();

            status.textContent =
                "نسخه پشتیبان تهیه شد. فایل را در جای امن نگهداری کنید.";

        } catch (error) {

            console.error("Backup Error:", error);

            status.textContent =
                error.message || "تهیه نسخه پشتیبان ناموفق بود.";

        } finally {

            exportButton.disabled = false;

        }

    });


    // انتخاب فایل
    fileInput.addEventListener("change", () => {

        const file = fileInput.files[0];

        importButton.disabled = !file;

        if (file) {

            status.textContent =
                `فایل انتخاب‌شده: ${file.name}`;

        } else {

            status.textContent = "";

        }

    });


    // بازیابی اطلاعات
    importButton.addEventListener("click", async () => {

        const file = fileInput.files[0];

        if (!file) return;

        const confirmed = confirm(
            "هشدار!\n\nتمام اطلاعات فعلی فروش، مشتریان، پرداخت‌ها و مصارف حذف و با اطلاعات فایل پشتیبان جایگزین می‌شوند.\n\nآیا مطمئن هستید؟"
        );

        if (!confirmed) return;

        importButton.disabled = true;

        status.textContent = "در حال بازیابی اطلاعات...";

        try {

            await importBackup(file);

            status.textContent =
                "اطلاعات با موفقیت بازیابی شد. صفحه در حال بارگذاری مجدد است...";

            setTimeout(() => {
                window.location.reload();
            }, 1500);

        } catch (error) {

            console.error("Restore Error:", error);

            status.textContent =
                error.message || "بازیابی اطلاعات ناموفق بود.";

            importButton.disabled = false;

        }

    });

}